package com.example.slotmachine.ImageViewScrolling;

public class Util {
    public static int BAR = 0,SEVEN = 1,ORANGE = 2,LEMON = 3,TRIPLE = 4,WATERMELON = 5;

}
