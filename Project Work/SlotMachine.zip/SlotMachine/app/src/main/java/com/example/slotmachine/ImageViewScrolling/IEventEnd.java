package com.example.slotmachine.ImageViewScrolling;

public interface IEventEnd {
    void eventEnd(int result,int count);

}
