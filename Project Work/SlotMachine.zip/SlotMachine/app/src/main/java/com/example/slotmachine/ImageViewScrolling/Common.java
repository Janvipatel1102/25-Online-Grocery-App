package com.example.slotmachine.ImageViewScrolling;

public class Common {
    public  static  int score = 200;

}
