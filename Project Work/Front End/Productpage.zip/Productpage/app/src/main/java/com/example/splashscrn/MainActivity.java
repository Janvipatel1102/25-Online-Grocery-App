package com.example.splashscrn;

import android.app.Activity;

public class MainActivity extends Activity {
}
