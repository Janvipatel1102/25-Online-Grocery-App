package com.example.splashscrn

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class productpage : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_productpage)
    }
}